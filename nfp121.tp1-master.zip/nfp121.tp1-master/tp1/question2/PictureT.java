package question2;
import question2.Picture;

/**
 * D�crivez votre classe TestPicture ici.
 *
 * @author (votre nom)
 * @version (un num�ro de version ou une date)
 */
public class  PictureT
{
      public static void main(final String[] args) { 
        Picture p;                           
        p = new Picture();
        
        p.draw();
         

       
        
    } 
}
